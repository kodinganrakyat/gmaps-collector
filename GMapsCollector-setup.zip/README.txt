GMapsCollector v1.2.7

Cara install:
1. Ekstrak ZIP ini
2. Jalankan GMapsCollector-setup.exe
3. Ikuti proses instalasi

Catatan:
Jika muncul peringatan dari Windows SmartScreen, klik "More info" lalu "Run anyway"

Website: https://gmapscollector.com
